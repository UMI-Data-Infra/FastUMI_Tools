#pragma once
#include <cstdint>

#define MAX_DEVICES 20
#define MAX_BUFFER_LENGTH 100
#define MAX_FISHEYE_IMAGES_NU 4
#define FISHEYE_IMAGE_SIZE (1024 * 1024)

#define STRING_MAX_LEN 255

typedef struct 
{
    char buffer[STRING_MAX_LEN];
} Version_Struct;

enum SLAM_START_MODE {
    NORMAL,
    VISION_ONLY,
    VISION_WITH_GYRO
};

enum DEVICE_SUPPORT{
    ONLY_USB,
    ONLY_DRIVER,
    USB_AND_DRIVER
};

typedef struct
{
    char id[MAX_BUFFER_LENGTH];
    void* handle = nullptr;
}Device_Item;

typedef struct
{
    Device_Item item[MAX_DEVICES];
    int cap = MAX_DEVICES;
    int size = 0;
}Devices;

typedef struct
{
    int aec_mode;
    int exposure_gain;
    float exposure_time_ms;
}Exposure_paras;

typedef struct {
    int width; //!< width of the image (in pixel)
    int height; //!< height of the image (in pixel)
    int8_t* data; //! image data (in row-major). Data size = width*height
}gray_scale_image;

typedef struct{
    double host_timestamp; //!< host timestamp of the physical measurement (in second based on the `std::chrono::steady_clock`), need to activate IMU stream (with SLAM or IMU callback) to have this value.
    int64_t edge_timestamp_us; //!< timestamp of the physical measurement (in microsecond based on edge clock).
    gray_scale_image images[MAX_FISHEYE_IMAGES_NU]; //! List of images (typically 2, first is left and second image is the right image)
    int image_number;
    int64_t id;//! Unique id given by the edge to this instance
}Fisheye_images;

struct Features{
    int64_t size; //! number of feature detected
    const float* keypoints; //! list of detected keypoints (xy) in image (size x 2 float elements)
    const unsigned char* descriptors; //! list of (DESC_SIZE x size) keypoints descriptors in image
};

typedef struct {
    int64_t version; //! Field use to help parsing and future evolutions of this struct
    int64_t id; //! Unique id given by the edge to this instance
    double hostTimestamp; //!< host timestamp of the physical measurement (in second based on the `std::chrono::steady_clock`), need to activate IMU stream (with SLAM or IMU callback) to have this value.
    int64_t edgeTimestampUs; //!< timestamp of the physical measurement (in microsecond based on edge clock).
    struct Features descriptors[2]; //! usually first is left and second is right, it is the same order fisheyes calibrations
    int descriptorSize;
}Fisheye_Key_Points_2;

typedef struct {
    int64_t version; //! Field use to help parsing and future evolutions of this struct
    int64_t id; //! Unique id given by the edge to this instance
    double hostTimestamp; //!< host timestamp of the physical measurement (in second based on the `std::chrono::steady_clock`), need to activate IMU stream (with SLAM or IMU callback) to have this value.
    int64_t edgeTimestampUs; //!< timestamp of the physical measurement (in microsecond based on edge clock).
    struct Features descriptors[4]; //! usually first is left and second is right, it is the same order fisheyes calibrations
    int descriptorSize;
}Fisheye_Key_Points_4;

enum Fisheye_Resolution_Mode{
    R_VGA,
    R_720P
};

typedef void (*fisheye_callback_ptr)(Fisheye_images* images, const char* device_name);
typedef void (*fisheye_2_key_points_callback_ptr)(Fisheye_Key_Points_2* images, const char* device_name);
typedef void (*fisheye_4_key_points_callback_ptr)(Fisheye_Key_Points_4* images, const char* device_name);

/**
 * @brief A color image in RGB format
 */
typedef struct {
    int width = 0; //!< width of the image (in pixel)
    int height = 0; //!< height of the image (in pixel)
    uint8_t* data; //! image data (in row-major) : RGB RGB RGB ....  Data size = width*height*3
}Rgb_Image;

enum Color_Image_Codec {
    YUYV = 0,
    YUV420p,
    JPEG,
    NV12,
    BITSTREAM
};

typedef struct{
    Color_Image_Codec codec;
    int width; //!< width of the image (in pixel)
    int height; //!< height of the image (in pixel)
    uint8_t* data; //! image data
    unsigned int data_size;
    double host_timestamp; //!< host timestamp of the physical measurement (in second based on the `std::chrono::steady_clock`).
    int64_t edge_timestamp_us; //!< timestamp of the physical measurement (in microsecond based on edge clock).
}Color_Image;

enum Color_Camera_Resolution
{
    RGB_1920x1080 = 0,  ///< RGB 1080p
    RGB_1280x720  = 1,  ///< RGB 720p
    RGB_640x480   = 2,  ///< RGB 480p
    RGB_320x240   = 3,  ///< RGB QVGA (not supported now)
    RGB_2560x1920 = 4,  ///< RGB 5m (not supported now)
    RGB_3840x2160 = 5,
};

typedef void (*rgb_callback_ptr)(Color_Image* images, const char* device_name);

// tof camera
enum Tof_Depth_Image_Type {
    Depth_16 = 0,
    Depth_32,
    IR,
    Cloud,
    Raw,
    Eeprom,
    IQ
};

enum Tof_Stream_Mode
{
    Depth_Only = 0,
    Cloud_Only,
    Depth_And_Cloud,
    None,
    Cloud_On_Left_Hand_Slam
};

enum Tof_Distance_Mode
{
    Short = 0,
    Middle,
    Long
};

enum Sony_Tof_Lib_Mode
{
    IQMIX_DF,
    IQMIX_SF,
    LABELIZE_DF,
    LABELIZE_SF,
    M2MIX_DF,
    M2MIX_SF 
};

enum Tof_Resolution
{
    Unknown_Resolution = -1,
    VGA = 0,
    QVGA,
    HQVGA
};

enum Tof_Framerate
{
    FPS_5,
    FPS_10,
    FPS_15,
    FPS_20,
    FPS_25,
    FPS_30 
};

enum Tof_Manufacturer
{
    Unknown_Manufacturer = -1,
    Pmd = 0,
    Sony
};

/**
 * @brief An image provided by a TOF camera.
 * @note  There are two manufacturers of TOF camera, Pmd and sony.
 *        Pmd TOF depth type is Depth_32，sony TOF depth type is Depth_16.
 *        Cloud type just use for Pmd point cloud,the coordinate system of the point cloud is the camera coordinate system, and the data unit is meters.
 *        Length, width and depth are in meters use Pmd TOF.
 *        Length, width and depth are in metmillimeterers use sony TOF. 
 */
typedef struct{
    Tof_Depth_Image_Type type;
    int width; //!< width of the image (in pixel)
    int height; //!< height of the image (in pixel)
    double  confidence; //!< confidence of depth [0.0,1.0]
    const uint8_t* data = nullptr; //! image of depth
    unsigned int data_size;
    double host_timestamp; //!< host timestamp of the physical measurement (in second based on the `std::chrono::steady_clock`).
    int64_t edge_timestamp_us; //!< timestamp of the physical measurement (in microsecond based on edge clock).
}Depth_Image;

typedef void (*tof_callback_ptr)(Depth_Image* images, const char* device_name);

//slam
enum Slam_Mode {
    Unknown_Mode = -1,
    Edge = 0,
    Mixed,
    Edge_Fusion_On_Host
};

typedef struct
{
    float x;
    float y;
    float z;
}Vector_3;

typedef struct
{
    float x;
    float y;
    float z;
    float w;
}Vector_4;

typedef struct
{
    Vector_3 position;
    Vector_3 orientation;
    Vector_4 quaternion;
    double confidence;
    double host_timestamp;
    long long edge_timestamp;
}Slam_Pose;

typedef void (*slam_callback_ptr)(Slam_Pose pose, const char* device_name);

typedef void (*cslam_done_ptr)(int status,const char* device_name);

typedef void (*save_cslam_done_ptr)(int status,  int quality, const char* device_name);

typedef void (*cslam_localized_ptr)(float percent, const char* device_name);

//imu
typedef struct
{
    double data[3];
}Vector_3_double;

typedef struct
{
    bool data[3];
}Vector_3_bool;


typedef struct
{
    Vector_3_double gyro; //!< 3-axis gyrometer values (in rad/s)
    Vector_3_double accel; //!< 3-axis accelerometer values (in m/s²)
    Vector_3_bool accel_saturation; //!< 3-axis accel saturation status (true if saturating)
    Vector_3_double magneto; //!< 3-axis magnetometer values
    double temperature; //!< sensor temperature (in K)
    double host_timestamp; //!< host timestamp of the physical measurement (in second based on the `std::chrono::steady_clock`).
    int64_t edge_timestamp_us; 
}Imu_Data;

typedef void (*imu_callback_ptr)(Imu_Data data, const char* device_name);

#define GESTURE_DATA_SIZE 52
typedef struct{
    Slam_Pose pose[GESTURE_DATA_SIZE];
    float scale[2];   // 1 + 1
    int status[2];
    double timestamp[2];
    double fisheye_timestamp;
}Gesture_Data;

typedef void (*gesture_callback_ptr)(Gesture_Data data, const char* device_name);

//sgbm
typedef struct
{
    int32_t enable_dewarp;
    float dewarp_zoom_factor;
    int32_t enable_disparity;
    int32_t enable_depth;
    int32_t enable_point_cloud;
    float baseline;
    float fov;
    uint8_t disparity_confidence_threshold;
    float homography[9];
    int32_t enable_gamma;
    float gamma_value;
    int32_t enable_gaussian;
    uint8_t mode;//standard 0 /Default:LRcheck 1 /Extended 2 /Subpixel 3
    uint16_t max_distance;//mm
    uint16_t min_distance;//mm
}Sgbm_Config;

enum Sgbm_Image_Type{
    Sgbm_Disparity = 0,
    Sgbm_Depth,
    Sgbm_PointCloud
};

typedef struct{
    Sgbm_Image_Type type;
    int width = 0; //!< width of the image (in pixel)
    int height = 0; //!< height of the image (in pixel)
    const uint8_t* data; //! data of SGBM
    unsigned int data_Size = 0;
    double host_timestamp; //!< host timestamp of the physical measurement (in second based on the `std::chrono::steady_clock`).
    std::int64_t edge_timestamp_us;; //!< timestamp of the physical measurement (in microsecond based on edge clock).
}Sgbm_Image;

enum Sgbm_Resolution {
    Sgbm_640x480   = 0,  ///< SGBM 480p
    Sgbm_1280x720        ///< SGBM 720p
};

enum Sgbm_Mode { 
    Sgbm_Hardware = 0,
    Sgbm_Software
};

typedef void (*sgbm_callback_ptr)(Sgbm_Image image, const char* device_name);

