#pragma once

#include "CInterfaceTypes.h"
#ifdef WIN32
#define EXPORT_API __declspec(dllexport)
#else
#define EXPORT_API __attribute__((visibility("default")))
#endif

extern "C"
{
    bool get_sdk_version(Version_Struct* version);

    Devices* get_devices_until_timeout(double timeOut, char* desc, SLAM_START_MODE start_mode, DEVICE_SUPPORT device_support);

    //fisheye camera
    bool start_fisheye(void* device_handle);
    
    bool stop_fisheye(void* device_handle);
    
    bool register_fisheye_callback(void* device_handle, fisheye_callback_ptr callback_ptr);
    
    bool unregister_callback(void* device_handle);

    int register_fisheye_2_key_points_callback(void* device_handle, fisheye_2_key_points_callback_ptr callback);
    
    int register_fisheye_4_key_points_callback(void* device_handle, fisheye_4_key_points_callback_ptr callback);
    
    bool unregister_fisheye_2_key_points_callback(void* device_handle);
    
    bool unregister_fisheye_4_key_points_callback(void* device_handle);
    
    bool set_fisheye_resolution_mode(void* device_handle, Fisheye_Resolution_Mode mode);
    
    bool set_fisheye_framerate(void* device_handle, float framerate);
    
    bool set_fisheye_exposure(void* device_handle, int aecMode, int exposureGain, float exposureTime);

    //RGB camera
    bool start_rgb(void* device_handle);
    
    bool stop_rgb(void* device_handle);
    
    bool register_rgb_callback(void* device_handle, rgb_callback_ptr callback_ptr);
    
    bool unregister_rgb_callback(void* device_handle);
    
    bool set_rgb_resolution(void* device_handle, Color_Camera_Resolution resolution);
    
    bool set_rgb_framerate(void* device_handle, float framerate);
    
    bool set_rgb_exposure(void* device_handle, int aecMode, int exposureGain, float exposureTime);

    //TOF camera
    bool start_tof(void* device_handle);
    
    bool stop_tof(void* device_handle);

    bool register_tof_callback(void* device_handle, tof_callback_ptr callback_ptr );
    
    bool unregister_tof_callback(void* device_handle);

    bool set_tof_stream_mode(void* device_handle, Tof_Stream_Mode mode);
    
    bool set_framerate(void* device_handle, float framerate );
    
    bool set_distance_mode(void* device_handle, Tof_Distance_Mode mode);
    
    bool set_mode(void* device_handle, int mode);
    
    Tof_Resolution get_tof_resolution(void* device_handle);
    
    Tof_Manufacturer get_tof_manufacturer(void* device_handle);
    
    bool set_tof_lib_work_mode(void* device_handle, Sony_Tof_Lib_Mode mode);
    
    bool enable_tof_Ir(void* device_handle, bool enable);
    
    bool set_sony_tof_setting(void* device_handle, Sony_Tof_Lib_Mode mode, Tof_Resolution resolution, Tof_Framerate frameRate);
    
    void set_tof_Ir_gamma(void* device_handle, double gamma);
    
    void set_filter_file(void* device_handle, const char* filePath);

    //slam
    Slam_Mode get_slam_mode(void* device_handle);

    bool start_slam(void* device_handle);

    bool stop_slam(void* device_handle);

    bool start_slam_by_mode(void* device_handle, Slam_Mode mode);

    bool reset_slam(void* device_handle);

    bool pause_slam(void* device_handle);

    bool resume_slam(void* device_handle);

    bool get_slam_pose(void* device_handle, Slam_Pose* pose, double prediction);

    bool get_slam_pose_at(void* device_handle, Slam_Pose* pose, double timestamp);

    bool register_slam_callback(void* device_handle, slam_callback_ptr callback_ptr);

    bool unregister_slam_callback(void* device_handle);

    bool load_map_and_switch_to_Cslam(void* device_handle, const char* const map, cslam_done_ptr done_ptr, cslam_localized_ptr localized_ptr);
    
    bool save_map_and_switch_to_Cslam(void* device_handle, const char* const map, save_cslam_done_ptr done_ptr, cslam_localized_ptr localized_ptr);

    //imu

    bool start_imu(void* device_handle);

    bool stop_imu(void* device_handle);

    bool register_imu_callback(void* device_handle, imu_callback_ptr callback_ptr);
    
    bool unregister_imu_callback(void* device_handle);

    //gesture
    bool start_gesture(void* device_handle);

    bool stop_gesture(void* device_handle);

    bool set_gesture_platform(void* device_handle, int platform, bool ego);
    
    bool register_gesture_slam_keypoints_callback(void* device_handle, gesture_callback_ptr callback);
    
    bool unregister_gesture_slam_keypoints_callback(void* device_handle);

    //sgbm
    bool start_sgbm(void* device_handle);

    bool stop_sgbm(void* device_handle);

    int register_sgbm_callback(void* device_handle, sgbm_callback_ptr callback);
    
    bool unregister_sgbm_callback(void* device_handle);

    bool start_sgbm_with_string_config(void* device_handle, const char* sgbmConfig);

    bool start_sgbm_with_struct_config(void* device_handle, const Sgbm_Config* config);

    bool set_sgbm_resolution(void* device_handle, Sgbm_Resolution resolution);
    
    bool get_sgbm_resolution(void* device_handle, Sgbm_Resolution* resolution);

    bool sgbm_mode(void* device_handle, Sgbm_Mode* mode);
}


