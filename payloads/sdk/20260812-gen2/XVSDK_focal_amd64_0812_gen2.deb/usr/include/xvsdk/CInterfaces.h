#pragma once

#ifdef WIN32
#define EXPORT_API __declspec(dllexport)
#else
#define EXPORT_API __attribute__((visibility("default")))
#endif

#include <string>
#include <xv-types.h>

#include <xv-sdk-ex.h>
#include <xv-sdk.h>

struct Vector3
{
    float x;
    float y;
    float z;
};

struct Vector4
{
    float x;
    float y;
    float z;
    float w;
};

/**
 * @brief Rotation and translation structure
 */
struct transform
{
    double rotation[9];    //!< Rotation matrix (row major)
    double translation[3]; //!< Translation vector
};

struct TagData
{
    int tagID;
    Vector3 position;
    Vector3 orientation;
    Vector4 quaternion;
    long long edgeTimestamp;
    double hostTimestamp;
    double confidence;
};

struct TagTransData
{
    int tagID;
    Vector3 position;
    Vector3 orientation;
    Vector4 quaternion;
};


extern "C"
{
    namespace CInterfaces
    {
        EXPORT_API bool xv_device_init();
        EXPORT_API void xv_device_uninit();
        EXPORT_API bool xv_start_slam();
        EXPORT_API bool xv_stop_slam();
        EXPORT_API bool xv_reset_slam();
        EXPORT_API bool xv_get_6dof(Vector3* position, Vector3* orientation, Vector4* quaternion, long long* edgeTimestamp, double* hostTimestamp, double* confidence);
        EXPORT_API bool xv_get_6dof_prediction(Vector3* position, Vector3* orientation, Vector4* quaternion, long long* edgeTimestamp, double* hostTimestamp, double* confidence, double prediction);
        EXPORT_API bool xv_get_6dof_at_timestamp(Vector3* position, Vector3* orientation, Vector4* quaternion, long long* edgeTimestamp, double* hostTimestamp, double* confidence, double timestamp);
        EXPORT_API bool xv_start_stereo();
        EXPORT_API bool xv_get_stereo_info(int* width, int* height, long long* edgeTimestamp, double* hostTimestamp, unsigned int* dataSize);
        EXPORT_API bool xv_get_stereo_image(unsigned char* left, unsigned char* right);
        EXPORT_API bool xv_start_imu();
        EXPORT_API bool xv_get_imu(Vector3* accel, Vector3* gyro, long long* edgeTimestamp, double* hostTimestamp);
        EXPORT_API bool xv_start_rgb();
        EXPORT_API bool xv_get_rgb_info(int* width, int* height, long long* edgeTimestamp, double* hostTimestamp, unsigned int* dataSize, int* codec);
        EXPORT_API bool xv_get_rgb_image(unsigned char* data);
        EXPORT_API bool xv_start_tof();
        EXPORT_API bool xv_get_tof_info(int* width, int* height, long long* edgeTimestamp, double* hostTimestamp, unsigned int* dataSize, int* type);
        EXPORT_API bool xv_get_tof_image(unsigned char* data);
        EXPORT_API bool xv_start_sgbm();
        EXPORT_API bool xv_get_sgbm_info(int* width, int* height, long long* edgeTimestamp, double* hostTimestamp, unsigned int* dataSize);
        EXPORT_API bool xv_get_sgbm_image(unsigned char* data);
        EXPORT_API void xv_get_sn(std::vector<char>& sn);
        EXPORT_API void xv_get_fe_camera_intrinsics_param(int* trans_size, int* ucm_size);
        EXPORT_API void xv_get_fe_camera_intrinsics(transform* trans, xv::UnifiedCameraModel* ucm);
        EXPORT_API void xv_get_rgb_camera_intrinsics_param(int* trans_size, int* pdcm_size);
        EXPORT_API void xv_get_rgb_camera_intrinsics(transform* trans, xv::PolynomialDistortionCameraModel* pdcm);
        EXPORT_API void xv_get_tof_camera_intrinsics_param(int* trans_size, int* pdcm_size);
        EXPORT_API void xv_get_tof_camera_intrinsics(transform* trans, xv::PolynomialDistortionCameraModel* pdcm);
        EXPORT_API void xv_set_rgb_camera_resolution(xv::ColorCamera::Resolution resolution);
        EXPORT_API void xv_start_fe_tag_detector(char* tagFamily, double size, double refreshRate);
        EXPORT_API void xv_get_fe_tag_size(int* tagSize);
        EXPORT_API void xv_get_fe_tag_detection(TagData* tags);
        EXPORT_API void xv_get_fe_tag_withslam_size(char* tagFamily, double size, int* tagSize);
        EXPORT_API void xv_detect_fe_tags_withslam(TagData* tags);
        EXPORT_API void xv_get_fe_tag_withFE_size(char* tagFamily, double size, int* tagSize);
        EXPORT_API void xv_detect_fe_tags_withFE(TagData* tags, TagTransData* transform);
        EXPORT_API bool xv_stop_fe_tag_detector();
        EXPORT_API void xv_get_device_status_data(unsigned char* deviceStatusData);
        EXPORT_API bool xv_start_event();
        EXPORT_API bool xv_stop_event();
        EXPORT_API void xv_get_event_data(double* hostTimestamp, int64_t* edgeTimestamp, int* type, int* state);
        EXPORT_API bool xv_hidWriteAndRead(unsigned char* write, unsigned char* read);
        void saveImages(const char* name, const unsigned char* data, int len);
        EXPORT_API bool xv_set_fe_gain(int gain);
        EXPORT_API bool xv_set_fe_exposureTimeMs(int brightness);
        EXPORT_API bool xv_set_fe_gain_and_exposureTimeMs(int gain ,int brightness);
        EXPORT_API void xv_set_fe_autoExposure(bool autoExposure);
        EXPORT_API void xv_start_rgb_tag_detector(char* tagFamily, double size, double refreshRate);
        EXPORT_API void xv_get_rgb_tag_size(int* tagSize);
        EXPORT_API void xv_get_rgb_tag_detection(TagData* tags);
        EXPORT_API bool xv_stop_rgb_tag_detector();
        EXPORT_API bool xv_reset_sensor();
        EXPORT_API void xv_reset_pose_coordinate();
        EXPORT_API void xv_switch_log(int mode);
    }
}

