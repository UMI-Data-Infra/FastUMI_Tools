#ifndef __XV_DEV_WRAPPER_H__
#define __XV_DEV_WRAPPER_H__

#include "sensor_msgs/msg/camera_info.hpp"
#include "sensor_msgs/msg/image.hpp"
#include <sensor_msgs/image_encodings.hpp>

#include "geometry_msgs/msg/pose_stamped.hpp"
#include "geometry_msgs/msg/transform_stamped.hpp"

#include "builtin_interfaces/msg/duration.hpp"
#include "nav_msgs/msg/path.hpp"

#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include "fps_count.hpp"
#include "safe_queue.hpp"

#include "./head.h"
#include "safe_deque.hpp"
#include "safe_read_write.hpp"
#include "ThreadPool.hpp"

class xvision_ros2_node;

using namespace xv;
class xv_dev_wrapper
{
public:
    explicit xv_dev_wrapper(xvision_ros2_node *node, std::shared_ptr<xv::Device> device, std::string sn, int type);
    ~xv_dev_wrapper();
    //
    bool startImuOri(void);
    bool stopImuOri(void);
    bool getImuOri(rosOrientationStamped &oriStamped, const builtin_interfaces::msg::Duration &duration);
    bool getImuOriAt(rosOrientationStamped &oriStamped, const builtin_interfaces::msg::Time &time);

    //
    bool start_slam(void);
    bool stop_slam(void);
    bool slam_get_pose(geometry_msgs::msg::PoseStamped &poseSteamped, const builtin_interfaces::msg::Duration &prediction);
    bool slam_get_pose_at(geometry_msgs::msg::PoseStamped &poseSteamped, const builtin_interfaces::msg::Time &time);
    bool reset_slam(void);

    //
    bool start_tof(void);
    bool stop_tof(void);

    //
    bool start_rgb(void);
    bool stop_rgb(void);

    bool start_clamp(void);
    bool stop_clamp(void);

    bool start_spheretracker(void);
    bool stop_spheretracker(void);

    bool saveCslamMap(std::string filename);
    bool loadCslamMap(std::string filename);
    bool startController(std::string portAddress);
    bool stopController();

    void publishSlamFunc();
    void publishSlamPathFunc();
    void publishImuFunc();
    void publishRGBCameraImageFunc();
    void publicRGBRectCameraImageFunc();
    void publishRGBDCameraImageFunc();
    void publishTofCameraImageFunc();
    void publisheOrientationFunc();
    void publishFEImageFunc();
    void publishSGBMImageFunc();
    void publishEventFunc();
    void publishRGBPointCloudFunc();
    void publishClampFunc();
    void publishsphereTrackLeftFunc();
    void publishsphereTrackRightFunc();

    void set_flag(bool flag) { m_isRectification = flag; m_rectification_colorImage_deque.clear(); }
    void set_imu_flag(bool flag);

    void uninit(void);

public:
    enum FE_IMAGE_TYPE
    {
        LEFT_IMAGE = 0,
        RIGHT_IMAGE = 1,
        LEFT2_IMAGE = 2,
        RIGHT2_IMAGE = 3
    };

private:
    void init(void);
    void initImu(void);
    void initOrientationStream(void);
    void initFisheyeCameras(void);
    void initSlam(void);
    void initTofCamera();
    void initColorCamera();
    void initColorDepthCamera();
    void initEvent();
    void initClamp();

    void formatImuTopicMsg(rosImu &rosImu, const xv::Imu &xvImu);
    void formatXvOriToRosOriStamped(rosOrientationStamped &rosOrientation,
                                    const xv::Orientation &xvOrientation,
                                    const std::string &frameId);
    rclcpp::Time getHeaderStamp(double hostTimesStamp);
    rosCamInfo toRosCameraInfo(const xv::UnifiedCameraModel *const ucm,
                               const xv::PolynomialDistortionCameraModel *const pdcm);
    rosCamInfo toRosCameraInfo(const xv::SpecialUnifiedCameraModel *const seucm);

    //
    void registerFECallbackFunc(void);
    bool registerFEAntiDistortionCallbackFunc(void);
    void registerSGBMCallbackFunc(void);

    rosImage changeFEGrayScaleImage2RosImage(const GrayScaleImage &xvGrayImage, double timestamp, const std::string &frame_id);
    void getFECalibration();
    double get_sec(const builtin_interfaces::msg::Duration &prediction) const;
    double get_sec(const builtin_interfaces::msg::Time &timestamp) const;
    geometry_msgs::msg::PoseStamped to_ros_poseStamped(const Pose &xvPose, const std::string &frame_id);
    geometry_msgs::msg::PoseStamped to_ros_poseEdgeStamped(const Pose &xvPose, const std::string &frame_id);
    builtin_interfaces::msg::Time get_stamp_from_sec(double sec) const;
    builtin_interfaces::msg::Time get_stamp_from_microsec(double microsec) const;
    double steady_clock_now() const;
    nav_msgs::msg::Path toRosPoseStampedRetNavmsgs(const Pose &xvPose, const std::string &frame_id, nav_msgs::msg::Path &path);
    geometry_msgs::msg::TransformStamped toRosTransformStamped(const Pose &pose,
                                                               const std::string &parent_frame_id,
                                                               const std::string &frame_id);
    rosImage toRosImage(const DepthImage &xvDepthImage, const std::string &frame_id);
    rosImage toRosImage(const ColorImage &xvColorImage, const std::string &frame_id);
    rosImage toRosImage(const SgbmImage &xvSgbmDepthImage, const std::string &frame_id);
    rosImage toRosImage(const DepthColorImage &xvDepthColorImage, const std::string &frame_id);
    rosImage toRosImage(const RgbImage &xvRgbImage, const std::string &frame_id);
    rosImage toRosImageRaw(const DepthColorImage &xvDepthColorImage, const std::string &frame_id);

    rosImage sgbmRawDepthtoRosImage(const SgbmImage &xvSgbmDepthImage, const std::string &frame_id);
    cv::Mat toCvMatRGB(const ColorImage &xvColorImage);
    cv::Mat toCvMatRGBD(const DepthColorImage &rgbd);
    void toRosOrientationStamped(rosOrientationStamped &orientation, Orientation const &xvOrientation, const std::string &frame_id);
    void toRosColorDepthData(rosColorDepth &colorDephData, const std::string &frame_id);
    // rosController toRosControllerData(const WirelessControllerData data, const std::string& frame_id);
    void toRosEventStamped(rosEventData &event, Event const &xvEvent, const std::string &frame_id);
    void toRosButtonStamped(rosButtonMsg &button, xv::Event const &xvEvent, const std::string &frame_id);

    rosPointCloud2 toRosPointCloud(const DepthImage &xvDepthImage, const ColorImage &xvColorImage, const std::string &frame_id);

private:
    // constr
    xvision_ros2_node *m_node;
    std::shared_ptr<xv::Device> m_device;
    std::string m_sn;
    int m_type;

private:
    std::vector<xv::Calibration> m_xvFisheyesCalibs;
    std::vector<std::map<int /*height*/, rosCamInfo>> m_fisheyeCameraInfos;
    bool m_slam_pose_enable;
    bool m_slam_path_enable;
    bool m_fisheye_enable;

    rosCamInfo m_tofCameraInfo;
    rosCamInfo m_rgbCameraInfo;
    rosCamInfo m_rgbrectCameraInfo;
    rosCamInfo m_rgbdCameraInfo;
    rosCamInfo m_rgbdRawCameraInfo;
    rosCamInfo m_rgbPointCloudCameraInfo;

    xv::Calibration m_xvTofCalib;
    xv::CalibrationEx m_xvRGBCalib;
    xv::Calibration m_xvRGBDCalib;
    xv::CalibrationEx m_xvSgbmCalib;

    rosCamInfo m_sgbmCamInfo;
    int m_controllerCBID;

    nav_msgs::msg::Path m_path_msgs;

    // std::mutex m_tof_mutex;
    // DepthImage m_xvDepthImage;
    safe_rw<DepthImage> m_depthImage;
    safe_rw<ColorImage> m_colorImage;

    //DepthImage m_depthImage;
    //ColorImage m_colorImage;

    ///
    std::vector<std::thread> m_threads;
    ThreadPool m_rgbd_rect_pool;
    ThreadPool m_imu_pool;

    //
    safe_deque<Pose> m_slam_pose_deque;
    safe_deque<Pose> m_slam_path_pose_deque;
    safe_deque<Imu> m_imu_deque;
    safe_deque<DepthColorImage> m_depthColorImage_deque; // rgbd
    safe_deque<ColorImage> m_colorImage_deque;           // rgb
    safe_deque<ColorImage> m_rectification_colorImage_deque ;//= {2}; // rgb-rect
    safe_deque<DepthImage> m_depthImage_deque; // tof
    safe_deque<Orientation> m_orientation_deque;
    safe_deque<FisheyeImages> m_fisheyeimages_deque; // fisheye
    safe_deque<SgbmImage> m_sgbmImage_deque;
    safe_deque<Event> m_event_deque;
    safe_deque<ClampData> m_clamp_deque;
    safe_deque<Pose> m_sphereTrackLeft_deque;
    safe_deque<Pose> m_sphereTrackRight_deque;

    // pointcloud
    //safe_deque<DepthImage> m_pointcloud_depthImage_deque; //= {2};
    //safe_deque<ColorImage> m_pointcloud_colorImage_deque; //= {2};
    safe_deque<std::pair<DepthImage, ColorImage>> m_pointcloud_deque;
    
    bool m_isRectification = false;
};

#endif // __XV_DEV_WRAPPER_H__
