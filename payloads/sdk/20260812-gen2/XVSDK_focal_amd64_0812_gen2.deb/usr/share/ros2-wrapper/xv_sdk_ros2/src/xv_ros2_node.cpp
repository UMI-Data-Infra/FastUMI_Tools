#include "xv_ros2_node.h"
xvision_ros2_node::xvision_ros2_node(void) : Node("xvisio_SDK", rclcpp::NodeOptions()
                                                                    .automatically_declare_parameters_from_overrides(true)),
                                             count_(0),
                                             m_stopWatchDevices(false)
{
}

void xvision_ros2_node::init(void)
{
    // initFrameIDParameter();
    get_frameId_parameters();
    get_device_config_parameters();
    // initTopicAndServer();

    m_static_tf_broadcaster = std::make_shared<tf2_ros::StaticTransformBroadcaster>(shared_from_this());
    m_watchDevThread = std::thread(&xvision_ros2_node::watchDevices, this);
    m_watchControllerThread = std::thread(&xvision_ros2_node::watchControllers, this);
}

// module_name-size > 0 
std::string get_module_name(std::string sn, std::string module_name)
{
    bool is_slash = module_name[0]=='/';

    return "xv_sdk/SN" + sn + (is_slash?"":"/") + module_name;
}

void xvision_ros2_node::initTopicAndServer(std::string sn)
{
    //
    std::string imuPubName = get_module_name(sn, "imu");
    m_imuPublisher.emplace(sn, rclcpp::Publisher<rosImu>::SharedPtr());
    m_imuPublisher[sn] = this->create_publisher<rosImu>(imuPubName.c_str(), 10);

    //
    auto imu_set_flag = [this, sn](const std::shared_ptr<std_srvs::srv::SetBool::Request> request, std::shared_ptr<std_srvs::srv::SetBool::Response> response)
    {
        m_deviceMap[sn]->set_imu_flag(request->data);

        response->success = true;
        if (request->data)
        {
            response->message = "IMU frame rate increased.";
        }
        else
        {
            response->message = "IMU frame rate decreased.";
        }
    };

    std::string service_imu_flag_name = get_module_name(sn, "imu/flag");
    m_service_flag_imu_1000.emplace(sn, rclcpp::Service<std_srvs::srv::SetBool>::SharedPtr());
    m_service_flag_imu_1000[sn] = this->create_service<std_srvs::srv::SetBool>(service_imu_flag_name.c_str(), imu_set_flag);

    //
    // std::string oriPubName = get_module_name(sn, "orientation");
    // m_orientationPublisher.emplace(sn, rclcpp::Publisher<rosOrientationStamped>::SharedPtr());
    // m_orientationPublisher[sn] = this->create_publisher<rosOrientationStamped>(oriPubName.c_str(), 1);

    //
    auto imuSensor_startOri_callBack = [this, sn](const std::shared_ptr<std_srvs::srv::Trigger::Request> /*req*/,
                                                  std::shared_ptr<std_srvs::srv::Trigger::Response> res) -> bool
    {
        bool ret = m_deviceMap[sn] ? m_deviceMap[sn]->startImuOri() : false;
        res->success = ret;
        res->message = ret ? "successed" : "failed";
        return ret;
    };
    std::string oriStart = get_module_name(sn, "start_orientation");
    m_service_imuSensor_startOri.emplace(sn, rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr());
    m_service_imuSensor_startOri[sn] = this->create_service<std_srvs::srv::Trigger>(oriStart.c_str(), imuSensor_startOri_callBack);

    //
    auto imuSensor_stopOri_callBack = [this, sn](const std::shared_ptr<std_srvs::srv::Trigger::Request> /*req*/,
                                                 std::shared_ptr<std_srvs::srv::Trigger::Response> res) -> bool
    {
        bool ret = m_deviceMap[sn] ? m_deviceMap[sn]->stopImuOri() : false;
        res->success = ret;
        res->message = ret ? "successed" : "failed";
        return ret;
    };
    std::string oriStop = get_module_name(sn, "stop_orientation");
    m_service_imuSensor_stopOri.emplace(sn, rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr());
    m_service_imuSensor_stopOri[sn] = this->create_service<std_srvs::srv::Trigger>(oriStop.c_str(), imuSensor_stopOri_callBack);

    //
    auto imuSensor_getOri_callback = [this, sn](const std::shared_ptr<xv_ros2_msgs::srv::GetOrientation_Request> req,
                                                std::shared_ptr<xv_ros2_msgs::srv::GetOrientation_Response> res) -> bool
    {
        return m_deviceMap[sn] ? m_deviceMap[sn]->getImuOri(res->orientation, req->prediction) : false;
    };
    std::string getOri = get_module_name(sn, "get_orientation");
    m_service_imuSensor_getOri.emplace(sn, rclcpp::Service<xv_ros2_msgs::srv::GetOrientation>::SharedPtr());
    m_service_imuSensor_getOri[sn] = this->create_service<xv_ros2_msgs::srv::GetOrientation>(getOri.c_str(), imuSensor_getOri_callback);

    //
    auto imuSensor_getOriAt_callback = [this, sn](const std::shared_ptr<xv_ros2_msgs::srv::GetOrientationAt_Request> req,
                                                  std::shared_ptr<xv_ros2_msgs::srv::GetOrientationAt_Response> res) -> bool
    {
        return m_deviceMap[sn] ? m_deviceMap[sn]->getImuOriAt(res->orientation, req->timestamp) : false;
    };
    std::string getOriAt = get_module_name(sn, "get_orientation_at");
    m_service_imuSensor_getOriAt.emplace(sn, rclcpp::Service<xv_ros2_msgs::srv::GetOrientationAt>::SharedPtr());
    m_service_imuSensor_getOriAt[sn] = this->create_service<xv_ros2_msgs::srv::GetOrientationAt>(getOriAt.c_str(), imuSensor_getOriAt_callback);

    //
    std::string feImage0 = get_module_name(sn, "fisheye_cameras_left/image");
    m_fisheyeImageLeftPublisher.emplace(sn, image_transport::Publisher());
    m_fisheyeImageLeftPublisher[sn] = image_transport::create_publisher(
        this, feImage0.c_str()); // this->create_publisher<rosImage>("", 10);

    //
    std::string feInfo0 = get_module_name(sn, "fisheye_cameras_left/camera_info");
    m_fisheyeImageLeftInfoPublisher.emplace(sn, rclcpp::Publisher<rosCamInfo>::SharedPtr());
    m_fisheyeImageLeftInfoPublisher[sn] = this->create_publisher<rosCamInfo>(feInfo0.c_str(), 1);

    //
    std::string feImage1 = get_module_name(sn, "fisheye_cameras_right/image");
    m_fisheyeImageRightPublisher.emplace(sn, image_transport::Publisher());
    m_fisheyeImageRightPublisher[sn] = image_transport::create_publisher(
        this, feImage1.c_str()); // this->create_publisher<rosImage>("fisheye_cameras_right/image", 10);

    //
    std::string feInfo1 = get_module_name(sn, "fisheye_cameras_right/camera_info");
    m_fisheyeImageRightInfoPublisher.emplace(sn, rclcpp::Publisher<rosCamInfo>::SharedPtr());
    m_fisheyeImageRightInfoPublisher[sn] = this->create_publisher<rosCamInfo>(feInfo1.c_str(), 1);

    //
    std::string feImage2 = get_module_name(sn, "fisheye_cameras_left2/image");
    m_fisheyeImageLeft2Publisher.emplace(sn, image_transport::Publisher());
    m_fisheyeImageLeft2Publisher[sn] = image_transport::create_publisher(
        this, feImage2.c_str()); // this->create_publisher<rosImage>("", 10);

    //
    std::string feInfo2 = get_module_name(sn, "fisheye_cameras_left2/camera_info");
    m_fisheyeImageLeft2InfoPublisher.emplace(sn, rclcpp::Publisher<rosCamInfo>::SharedPtr());
    m_fisheyeImageLeft2InfoPublisher[sn] = this->create_publisher<rosCamInfo>(feInfo2.c_str(), 1);

    //
    std::string feImage3 = get_module_name(sn, "fisheye_cameras_right2/image");
    m_fisheyeImageRight2Publisher.emplace(sn, image_transport::Publisher());
    m_fisheyeImageRight2Publisher[sn] = image_transport::create_publisher(
        this, feImage3.c_str()); // this->create_publisher<rosImage>("fisheye_cameras_right/image", 10);

    //
    std::string feInfo3 = get_module_name(sn, "fisheye_cameras_right2/camera_info");
    m_fisheyeImageRight2InfoPublisher.emplace(sn, rclcpp::Publisher<rosCamInfo>::SharedPtr());
    m_fisheyeImageRight2InfoPublisher[sn] = this->create_publisher<rosCamInfo>(feInfo3.c_str(), 1);

    // //
    // std::string feImageAnti0 = get_module_name(sn, "fisheye_AntiDistortion_cameras_left/image");
    // m_fisheyeAntiDistortionLeftImagePublisher.emplace(sn, image_transport::Publisher());
    // m_fisheyeAntiDistortionLeftImagePublisher[sn] = image_transport::create_publisher(
    //     this, feImageAnti0.c_str()); // this->create_publisher<rosImage>("", 10);

    // //
    // std::string feInfoAnti0 = get_module_name(sn, "fisheye_AntiDistortion_cameras_left/camera_info");
    // m_fisheyeAntiDistortionCamLeftInfoPublisher.emplace(sn, rclcpp::Publisher<rosCamInfo>::SharedPtr());
    // m_fisheyeAntiDistortionCamLeftInfoPublisher[sn] = this->create_publisher<rosCamInfo>(feInfoAnti0.c_str(), 1);

    // //
    // std::string feImageAnti1 = get_module_name(sn, "fisheye_AntiDistortion_cameras_right/image");
    // m_fisheyeAntiDistortionRightImagePublisher.emplace(sn, image_transport::Publisher());
    // m_fisheyeAntiDistortionRightImagePublisher[sn] = image_transport::create_publisher(
    //     this, feImageAnti1.c_str()); // this->create_publisher<rosImage>("fisheye_cameras_right/image", 10);

    // //
    // std::string feInfoAnti1 = get_module_name(sn, "fisheye_AntiDistortion_cameras_right/camera_info");
    // m_fisheyeAntiDistortionCamRightInfoPublisher.emplace(sn, rclcpp::Publisher<rosCamInfo>::SharedPtr());
    // m_fisheyeAntiDistortionCamRightInfoPublisher[sn] = this->create_publisher<rosCamInfo>(feInfoAnti1.c_str(), 1);

    //
    auto slam_start_service_callback = [this, sn](const std::shared_ptr<std_srvs::srv::Trigger::Request> /*req*/,
                                                  std::shared_ptr<std_srvs::srv::Trigger::Response> res) -> bool
    {
        bool ret = m_deviceMap[sn] ? m_deviceMap[sn]->start_slam() : false;
        res->success = ret;
        res->message = ret ? "successed" : "failed";
        return ret;
    };
    std::string startSlam = get_module_name(sn, "start_slam");
    m_service_slam_start.emplace(sn, rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr());
    m_service_slam_start[sn] = this->create_service<std_srvs::srv::Trigger>(startSlam.c_str(), slam_start_service_callback);

    auto slam_reset_service_callback = [this, sn](const std::shared_ptr<std_srvs::srv::Trigger::Request> /*req*/,
                                                  std::shared_ptr<std_srvs::srv::Trigger::Response> res) -> bool
    {
        bool ret = m_deviceMap[sn] ? m_deviceMap[sn]->reset_slam() : false;
        res->success = ret;
        res->message = ret ? "successed" : "failed";
        return ret;
    };
    std::string resetSlam = get_module_name(sn, "reset_slam");
    m_service_slam_reset.emplace(sn, rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr());
    m_service_slam_reset[sn] = this->create_service<std_srvs::srv::Trigger>(resetSlam.c_str(), slam_reset_service_callback);

    //
    auto slam_stop_service_callback = [this, sn](const std::shared_ptr<std_srvs::srv::Trigger::Request> /*req*/,
                                                 std::shared_ptr<std_srvs::srv::Trigger::Response> res) -> bool
    {
        bool ret = m_deviceMap[sn] ? m_deviceMap[sn]->stop_slam() : false;
        res->success = ret;
        res->message = ret ? "successed" : "failed";
        return ret;
    };

    //
    std::string stopSlam = get_module_name(sn, "stop_slam");
    m_service_slam_stop.emplace(sn, rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr());
    m_service_slam_stop[sn] = this->create_service<std_srvs::srv::Trigger>(stopSlam.c_str(), slam_stop_service_callback);

    auto slam_get_pose_service_callback = [this, sn](const std::shared_ptr<xv_ros2_msgs::srv::GetPose::Request> req,
                                                     std::shared_ptr<xv_ros2_msgs::srv::GetPose::Response> res) -> bool
    {
        bool ret = m_deviceMap[sn] ? m_deviceMap[sn]->slam_get_pose(res->pose, req->prediction) : false;
        return ret;
    };

    //
    std::string getPose = get_module_name(sn, "get_pose");
    m_service_slam_get_pose.emplace(sn, rclcpp::Service<xv_ros2_msgs::srv::GetPose>::SharedPtr());
    m_service_slam_get_pose[sn] = this->create_service<xv_ros2_msgs::srv::GetPose>(getPose.c_str(), slam_get_pose_service_callback);

    //
    auto slam_get_pose_at_service_callback = [this, sn](const std::shared_ptr<xv_ros2_msgs::srv::GetPoseAt::Request> req,
                                                        std::shared_ptr<xv_ros2_msgs::srv::GetPoseAt::Response> res) -> bool
    {
        bool ret = m_deviceMap[sn] ? m_deviceMap[sn]->slam_get_pose_at(res->pose, req->timestamp) : false;
        return ret;
    };

    //
    std::string getPoseAt = get_module_name(sn, "get_pose_at");
    m_service_slam_get_pose_at.emplace(sn, rclcpp::Service<xv_ros2_msgs::srv::GetPoseAt>::SharedPtr());
    m_service_slam_get_pose_at[sn] = this->create_service<xv_ros2_msgs::srv::GetPoseAt>(getPoseAt.c_str(), slam_get_pose_at_service_callback);

    if (m_deviceConfig["slam_pose_enable"])
    {
        std::string slamPose = get_module_name(sn, "pose");
        m_slam_pose_publisher.emplace(sn, rclcpp::Publisher<geometry_msgs::msg::PoseStamped>::SharedPtr());
        m_slam_pose_publisher[sn] = this->create_publisher<geometry_msgs::msg::PoseStamped>(slamPose.c_str(), 10);
    }

    // if (m_deviceConfig["slam_path_enable"])
    // {
    //     std::string trajectory = get_module_name(sn, "trajectory");
    //     m_slam_path_publisher.emplace(sn, rclcpp::Publisher<nav_msgs::msg::Path>::SharedPtr());
    //     m_slam_path_publisher[sn] = this->create_publisher<nav_msgs::msg::Path>(trajectory.c_str(), 1);
    // }

    // auto tof_start_service_callback = [this, sn](const std::shared_ptr<std_srvs::srv::Trigger::Request> /*req*/,
    //                                     std::shared_ptr<std_srvs::srv::Trigger::Response> res) -> bool
    // {
    //     bool ret = m_deviceMap[sn] ? m_deviceMap[sn]->start_tof() : false;
    //     res->success = ret;
    //     res->message = ret ? "successed" : "failed";
    //     return ret;
    // };
    // std::string startTOF = get_module_name(sn,"start_tof";
    // rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr tofStart;
    // m_service_tof_start.emplace(sn, tofStart);
    // m_service_tof_start[sn] = this->create_service<std_srvs::srv::Trigger>(startTOF.c_str(), tof_start_service_callback);

    // auto tof_stop_service_callback = [this, sn](const std::shared_ptr<std_srvs::srv::Trigger::Request> /*req*/,
    //                                     std::shared_ptr<std_srvs::srv::Trigger::Response> res) -> bool
    // {
    //     bool ret = m_deviceMap[sn] ? m_deviceMap[sn]->stop_tof() : false;
    //     res->success = ret;
    //     res->message = ret ? "successed" : "failed";
    //     return ret;
    // };
    // std::string stopTOF = get_module_name(sn,"stop_tof";
    // rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr tofStop;
    // m_service_tof_stop.emplace(sn, tofStop);
    // m_service_tof_stop[sn] = this->create_service<std_srvs::srv::Trigger>(stopTOF.c_str(), tof_stop_service_callback);

    //
    std::string tofImage = get_module_name(sn, "tof/depth/image_rect_raw");
    m_tof_camera_publisher.emplace(sn, image_transport::Publisher());
    m_tof_camera_publisher[sn] = image_transport::create_publisher(
        this, tofImage.c_str()); // image_transport::create_camera_publisher(this, "camera/depth/image_rect_raw");

    //
    std::string tofInfo = get_module_name(sn, "tof/depth/camera_info");
    m_tof_cameraInfo_pub.emplace(sn, rclcpp::Publisher<rosCamInfo>::SharedPtr());
    m_tof_cameraInfo_pub[sn] = this->create_publisher<rosCamInfo>(
        tofInfo.c_str(), 1);

    // auto rgb_start_service_callback = [this, sn](const std::shared_ptr<std_srvs::srv::Trigger::Request> /*req*/,
    //                                     std::shared_ptr<std_srvs::srv::Trigger::Response> res) -> bool
    // {
    //     bool ret = m_deviceMap[sn] ? m_deviceMap[sn]->start_rgb() : false;
    //     res->success = ret;
    //     res->message = ret ? "successed" : "failed";
    //     return ret;
    // };
    // std::string startRGB = get_module_name(sn,"start_rgb)";
    // rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr rgbStartSrv;
    // m_service_rgb_start.emplace(sn, rgbStartSrv);
    // m_service_rgb_start[sn] = this->create_service<std_srvs::srv::Trigger>(startRGB.c_str(), rgb_start_service_callback);

    // auto rgb_stop_service_callback = [this, sn](const std::shared_ptr<std_srvs::srv::Trigger::Request> /*req*/,
    //                                     std::shared_ptr<std_srvs::srv::Trigger::Response> res) -> bool
    // {
    //     bool ret = m_deviceMap[sn] ? m_deviceMap[sn]->stop_rgb() : false;
    //     res->success = ret;
    //     res->message = ret ? "successed" : "failed";
    //     return ret;
    // };
    // std::string stopRGB = get_module_name(sn,"stop_rgb)";
    // rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr rgbStopSrv;
    // m_service_rgb_stop.emplace(sn, rgbStopSrv);
    // m_service_rgb_stop[sn] = this->create_service<std_srvs::srv::Trigger>(stopRGB.c_str(), rgb_stop_service_callback);

    // rgb
    //
    std::string rgbImage = get_module_name(sn, "rgb/image");
    m_rgb_camera_publisher.emplace(sn, image_transport::Publisher());
    m_rgb_camera_publisher[sn] = image_transport::create_publisher(
        this, rgbImage.c_str());
        
    //
    std::string rgbInfo = get_module_name(sn, "rgb/camera_info");
    m_rgb_cameraInfo_pub.emplace(sn, rclcpp::Publisher<rosCamInfo>::SharedPtr());
    m_rgb_cameraInfo_pub[sn] = this->create_publisher<rosCamInfo>(rgbInfo.c_str(), 1);
       
    // rgb_rect
    // 
    std::string rgb_rect_image = get_module_name(sn, "rgb_rectification/image");
    m_rgb_rect_camera_publisher.emplace(sn, image_transport::Publisher());
    m_rgb_rect_camera_publisher[sn] = image_transport::create_publisher(this, rgb_rect_image.c_str());

    //
    std::string rgb_rect_info = get_module_name(sn, "rgb_rectification/camera_info");
    m_rgb_rect_cameraInfo_pub.emplace(sn, rclcpp::Publisher<rosCamInfo>::SharedPtr());
    m_rgb_rect_cameraInfo_pub[sn] = this->create_publisher<rosCamInfo>(rgb_rect_info.c_str(), 1);

    // std::string sgbmImage = get_module_name(sn,"sgbm/image");
    // image_transport::Publisher sgbmImagePub;
    // m_sgbm_camera_publisher.emplace(sn, sgbmImagePub);
    // m_sgbm_camera_publisher[sn] = image_transport::create_publisher(
    //     this, sgbmImage.c_str());
    // std::string sgbmInfo = get_module_name(sn,"sgbm/camera_info");
    // rclcpp::Publisher<rosCamInfo>::SharedPtr sgbmImageInfoPub;
    // m_sgbm_cameraInfo_pub.emplace(sn, sgbmImageInfoPub);
    // m_sgbm_cameraInfo_pub[sn] = this->create_publisher<rosCamInfo>(sgbmInfo.c_str(), 1);
    // std::string sgbmRawImage = get_module_name(sn,"sgbm/sgbmRaw/image");
    // image_transport::Publisher sgbmRawImagePub;
    // m_sgbm_raw_camera_publisher.emplace(sn, sgbmRawImagePub);
    // m_sgbm_raw_camera_publisher[sn] = image_transport::create_publisher(
    //     this, sgbmRawImage.c_str());
    // std::string sgbmRawImageInfo = get_module_name(sn,"sgbm/sgbmRaw/camera_info");
    // rclcpp::Publisher<rosCamInfo>::SharedPtr sgbmRawImageInfoPub;
    // m_sgbm_raw_cameraInfo_pub.emplace(sn, sgbmRawImageInfoPub);
    // m_sgbm_raw_cameraInfo_pub[sn] = this->create_publisher<rosCamInfo>(sgbmRawImageInfo.c_str(), 1);

    //
    std::string rgbdImage = get_module_name(sn, "rgbd/image");
    m_rgbd_camera_publisher.emplace(sn, image_transport::Publisher());
    m_rgbd_camera_publisher[sn] = image_transport::create_publisher(
        this, rgbdImage.c_str());

    //
    std::string rgbdInfo = get_module_name(sn, "rgbd/camera_info");
    m_rgbd_cameraInfo_pub.emplace(sn, rclcpp::Publisher<rosCamInfo>::SharedPtr());
    m_rgbd_cameraInfo_pub[sn] = this->create_publisher<rosCamInfo>(rgbdInfo.c_str(), 1);

    //
    std::string rgbdRawImage = get_module_name(sn, "rgbd/raw/image");
    m_rgbd_raw_camera_publisher.emplace(sn, image_transport::Publisher());
    m_rgbd_raw_camera_publisher[sn] = image_transport::create_publisher(
        this, rgbdRawImage.c_str());

    //
    std::string rgbdRawInfo = get_module_name(sn, "rgbd/raw/camera_info");
    m_rgbd_raw_cameraInfo_pub.emplace(sn, rclcpp::Publisher<rosCamInfo>::SharedPtr());
    m_rgbd_raw_cameraInfo_pub[sn] = this->create_publisher<rosCamInfo>(rgbdRawInfo.c_str(), 1);

    //
    std::string rgbdRaw = get_module_name(sn, "rgbd/raw/data");
    m_rgbd_raw_data_publisher.emplace(sn, rclcpp::Publisher<rosColorDepth>::SharedPtr());
    m_rgbd_raw_data_publisher[sn] = this->create_publisher<rosColorDepth>(rgbdRaw.c_str(), 1);

    //
    auto cslam_savemap_service_callback = [this, sn](const std::shared_ptr<xv_ros2_msgs::srv::SaveMapAndSwitchCslam::Request> req,
                                                     std::shared_ptr<xv_ros2_msgs::srv::SaveMapAndSwitchCslam::Response> res) -> bool
    {
        bool ret = m_deviceMap[sn]->saveCslamMap(req->filename);
        if (ret)
        {
            res->success = true;
            res->message = "save map file ok";
        }
        else
        {
            res->success = false;
            res->message = "could not save map file";
        }
        return ret;
    };
    std::string cslamSave = get_module_name(sn, "cslam_save_map");
    rclcpp::Service<xv_ros2_msgs::srv::SaveMapAndSwitchCslam>::SharedPtr saveMapSrv;
    m_cslam_save_map.emplace(sn, saveMapSrv);
    m_cslam_save_map[sn] = this->create_service<xv_ros2_msgs::srv::SaveMapAndSwitchCslam>(cslamSave.c_str(), cslam_savemap_service_callback);

    //
    auto cslam_loadmap_service_callback = [this, sn](const std::shared_ptr<xv_ros2_msgs::srv::LoadMapAndSwitchCslam::Request> req,
                                                     std::shared_ptr<xv_ros2_msgs::srv::LoadMapAndSwitchCslam::Response> res) -> bool
    {
        bool ret = m_deviceMap[sn]->loadCslamMap(req->filename);
        if (ret)
        {
            res->success = true;
            res->message = "load map file ok";
        }
        else
        {
            res->success = false;
            res->message = "could not load map file";
        }
        return ret;
    };
    std::string cslamLoad = get_module_name(sn, "cslam_load_map");
    m_cslam_load_map.emplace(sn, rclcpp::Service<xv_ros2_msgs::srv::LoadMapAndSwitchCslam>::SharedPtr());
    m_cslam_load_map[sn] = this->create_service<xv_ros2_msgs::srv::LoadMapAndSwitchCslam>(cslamLoad.c_str(), cslam_loadmap_service_callback);

    //
    // std::string eventName = get_module_name(sn, "event");
    // m_eventPublisher.emplace(sn, rclcpp::Publisher<rosEventData>::SharedPtr());
    // m_eventPublisher[sn] = this->create_publisher<rosEventData>(eventName.c_str(), 1);

    // //
    // std::string buttonName1 = get_module_name(sn, "button1");
    // m_buttonPublisher1.emplace(sn, rclcpp::Publisher<rosButtonMsg>::SharedPtr());
    // m_buttonPublisher1[sn] = this->create_publisher<rosButtonMsg>(buttonName1.c_str(), 1);

    // //
    // std::string buttonName2 = get_module_name(sn, "button2");
    // m_buttonPublisher2.emplace(sn, rclcpp::Publisher<rosButtonMsg>::SharedPtr());
    // m_buttonPublisher2[sn] = this->create_publisher<rosButtonMsg>(buttonName2.c_str(), 1);

    // //
    // std::string buttonName3 = get_module_name(sn, "button3");
    // m_buttonPublisher3.emplace(sn, rclcpp::Publisher<rosButtonMsg>::SharedPtr());
    // m_buttonPublisher3[sn] = this->create_publisher<rosButtonMsg>(buttonName3.c_str(), 1);

    // //
    // std::string buttonName4 = get_module_name(sn, "button4");
    // m_buttonPublisher4.emplace(sn, rclcpp::Publisher<rosButtonMsg>::SharedPtr());
    // m_buttonPublisher4[sn] = this->create_publisher<rosButtonMsg>(buttonName4.c_str(), 1);

    //
    std::string rgbPointCloudPubName = get_module_name(sn, "rgbPointCloud");
    m_rgbPointCloudPublisher.emplace(sn, rclcpp::Publisher<rosPointCloud2>::SharedPtr());
    m_rgbPointCloudPublisher[sn] = this->create_publisher<rosPointCloud2>(rgbPointCloudPubName.c_str(), 1);

    //
    std::string rgbPointCloudInfo = get_module_name(sn, "rgbPointCloud/camera_info");
    m_rgbPointCloud_cameraInfo_pub.emplace(sn, rclcpp::Publisher<rosCamInfo>::SharedPtr());
    m_rgbPointCloud_cameraInfo_pub[sn] = this->create_publisher<rosCamInfo>(rgbPointCloudInfo.c_str(), 1);

    // rgb-rect
    auto handle_set_flag = [this, sn](const std::shared_ptr<std_srvs::srv::SetBool::Request> request,
                                      std::shared_ptr<std_srvs::srv::SetBool::Response> response) -> void
    {
        m_deviceMap[sn]->set_flag(request->data);

        printInfoMsg("Flag set to: " + std::string(request->data ? "True" : "False"));

        response->success = true;
        response->message = "Publishing " + std::string(request->data ? "rectified" : "origin") + " image";
    };
    std::string service_flag_RectImage_pub_name = get_module_name(sn, "rgb/flag");
    m_service_flag_rectification_image.emplace(sn, rclcpp::Service<std_srvs::srv::SetBool>::SharedPtr());
    m_service_flag_rectification_image[sn] = this->create_service<std_srvs::srv::SetBool>(service_flag_RectImage_pub_name.c_str(), handle_set_flag);

    std::string clampPubName = get_module_name(sn, "clamp");
    m_clampPublisher.emplace(sn, rclcpp::Publisher<rosClamp>::SharedPtr());
    m_clampPublisher[sn] = this->create_publisher<rosClamp>(clampPubName.c_str(), 1);
    auto clamp_start_service_callback = [this, sn](const std::shared_ptr<std_srvs::srv::Trigger::Request> /*req*/,
                                                  std::shared_ptr<std_srvs::srv::Trigger::Response> res) -> bool
    {
        bool ret = m_deviceMap[sn] ? m_deviceMap[sn]->start_clamp() : false;
        res->success = ret;
        res->message = ret ? "successed" : "failed";
        return ret;
    };
    std::string startClamp = get_module_name(sn, "start_clamp");
    m_service_clamp_start.emplace(sn, rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr());
    m_service_clamp_start[sn] = this->create_service<std_srvs::srv::Trigger>(startClamp.c_str(), clamp_start_service_callback);

    //
    auto clamp_stop_service_callback = [this, sn](const std::shared_ptr<std_srvs::srv::Trigger::Request> /*req*/,
                                                 std::shared_ptr<std_srvs::srv::Trigger::Response> res) -> bool
    {
        bool ret = m_deviceMap[sn] ? m_deviceMap[sn]->stop_clamp() : false;
        res->success = ret;
        res->message = ret ? "successed" : "failed";
        return ret;
    };

    //
    std::string stopClamp = get_module_name(sn, "stop_clamp");
    m_service_clamp_stop.emplace(sn, rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr());
    m_service_clamp_stop[sn] = this->create_service<std_srvs::srv::Trigger>(stopClamp.c_str(), clamp_stop_service_callback);

    std::string leftSpherePubName = get_module_name(sn, "tof/sphereTracker/left");
    m_leftSpherePublisher.emplace(sn, rclcpp::Publisher<geometry_msgs::msg::PoseStamped>::SharedPtr());
    m_leftSpherePublisher[sn] = this->create_publisher<geometry_msgs::msg::PoseStamped>(leftSpherePubName.c_str(), 1);

    std::string rightSpherePubName = get_module_name(sn, "tof/sphereTracker/right");
    m_rightSpherePublisher.emplace(sn, rclcpp::Publisher<geometry_msgs::msg::PoseStamped>::SharedPtr());
    m_rightSpherePublisher[sn] = this->create_publisher<geometry_msgs::msg::PoseStamped>(rightSpherePubName.c_str(), 1);

    auto sphere_start_service_callback = [this, sn](const std::shared_ptr<std_srvs::srv::Trigger::Request> /*req*/,
                                                  std::shared_ptr<std_srvs::srv::Trigger::Response> res) -> bool
    {
        bool ret = m_deviceMap[sn] ? m_deviceMap[sn]->start_spheretracker() : false;
        res->success = ret;
        res->message = ret ? "successed" : "failed";
        return ret;
    };
    std::string startSpheretracker = get_module_name(sn, "start_spheretracker");
    m_service_spheretrack_start.emplace(sn, rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr());
    m_service_spheretrack_start[sn] = this->create_service<std_srvs::srv::Trigger>(startSpheretracker.c_str(), sphere_start_service_callback);

    //
    auto sphere_stop_service_callback = [this, sn](const std::shared_ptr<std_srvs::srv::Trigger::Request> /*req*/,
                                                 std::shared_ptr<std_srvs::srv::Trigger::Response> res) -> bool
    {
        bool ret = m_deviceMap[sn] ? m_deviceMap[sn]->stop_spheretracker() : false;
        res->success = ret;
        res->message = ret ? "successed" : "failed";
        return ret;
    };

    //
    std::string stopSpheretracker = get_module_name(sn, "stop_spheretracker");
    m_service_spheretrack_stop.emplace(sn, rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr());
    m_service_spheretrack_stop[sn] = this->create_service<std_srvs::srv::Trigger>(stopSpheretracker.c_str(), sphere_stop_service_callback);
}

void xvision_ros2_node::initControllerTopicAndServer(std::string sn)
{
    //
    std::string controllerLeftPose = get_module_name(sn, "leftControllerPose");
    m_controller_left_pose_publisher.emplace(sn, rclcpp::Publisher<geometry_msgs::msg::PoseStamped>::SharedPtr());
    m_controller_left_pose_publisher[sn] = this->create_publisher<geometry_msgs::msg::PoseStamped>(controllerLeftPose.c_str(), 10);

    //
    std::string controllerRightPose = get_module_name(sn, "rightControllerPose");
    m_controller_right_pose_publisher.emplace(sn,  rclcpp::Publisher<geometry_msgs::msg::PoseStamped>::SharedPtr ());
    m_controller_right_pose_publisher[sn] = this->create_publisher<geometry_msgs::msg::PoseStamped>(controllerRightPose.c_str(), 10);

    //
    std::string controllerLeftData = get_module_name(sn, "leftControllerData");
    m_controller_left_data_publisher.emplace(sn, rclcpp::Publisher<rosController>::SharedPtr());
    m_controller_left_data_publisher[sn] = this->create_publisher<rosController>(controllerLeftData.c_str(), 10);

    //
    std::string controllerRightData = get_module_name(sn, "rightControllerData");
    m_controller_right_data_publisher.emplace(sn,  rclcpp::Publisher<rosController>::SharedPtr ());
    m_controller_right_data_publisher[sn] = this->create_publisher<rosController>(controllerRightData.c_str(), 10);

    std::cout << "start controller port " << this->getFrameID("controller_port") << std::endl;
    m_controllerMap[sn]->startController(this->getFrameID("controller_port"));
    // auto controller_start_service_callback = [this, sn](const std::shared_ptr<xv_ros2_msgs::srv::ControllerStart::Request> req,
    //                                     std::shared_ptr<xv_ros2_msgs::srv::ControllerStart::Response> res) -> bool
    // {
    //     std::cout << "port address: " << req->portaddress << std::endl;
    //     bool ret = m_controllerMap[sn]->startController(req->portaddress);
    //     if(ret)
    //     {
    //         res->success = true;
    //         res->message = "start controller ok";
    //     }
    //     else
    //     {
    //         res->success = false;
    //         res->message = "could not start controller";
    //     }
    //     return ret;
    // };
    // std::string controllerStart = get_module_name(sn,"controller_start");
    // rclcpp::Service<xv_ros2_msgs::srv::ControllerStart>::SharedPtr startControllerSrv;
    // m_controller_start.emplace(sn, startControllerSrv);
    // m_controller_start[sn] = this->create_service<xv_ros2_msgs::srv::ControllerStart>(controllerStart.c_str(), controller_start_service_callback);

    // auto controller_stop_service_callback = [this, sn](const std::shared_ptr<xv_ros2_msgs::srv::ControllerStop::Request> /*req*/,
    //                                     std::shared_ptr<xv_ros2_msgs::srv::ControllerStop::Response> res) -> bool
    // {
    //     bool ret = m_controllerMap[sn]->stopController();
    //     if(ret)
    //     {
    //         res->success = true;
    //         res->message = "stop controller ok";
    //     }
    //     else
    //     {
    //         res->success = false;
    //         res->message = "could not stop controller";
    //     }
    //     return ret;
    // };
    // std::string controllerStop = get_module_name(sn,"controller_stop");
    // rclcpp::Service<xv_ros2_msgs::srv::ControllerStop>::SharedPtr stopControllerSrv;
    // m_controller_stop.emplace(sn, stopControllerSrv);
    // m_controller_stop[sn] = this->create_service<xv_ros2_msgs::srv::ControllerStop>(controllerStop.c_str(), controller_stop_service_callback);
}

void xvision_ros2_node::initFrameIDParameter(void)
{
    this->declare_parameter<std::string>("map_optical_frame",
                                         "map_optical_frame");
    this->declare_parameter<std::string>("imu_optical_frame",
                                         "imu_optical_frame");
    this->declare_parameter<std::string>("imu_optical_frame_unfiltered",
                                         "imu_optical_frame_unfiltered");
    this->declare_parameter<std::string>("fisheye_left_optical_frame",
                                         "fisheye_left_optical_frame");
    this->declare_parameter<std::string>("fisheye_right_optical_frame",
                                         "fisheye_right_optical_frame");
    this->declare_parameter<std::string>("color_optical_frame",
                                         "color_optical_frame");
    this->declare_parameter<std::string>("sgbm_optical_frame",
                                         "sgbm_optical_frame");
    this->declare_parameter<std::string>("tof_optical_frame",
                                         "tof_optical_frame");
    this->declare_parameter<std::string>("imu_link",
                                         "imu_link");
    this->declare_parameter<std::string>("base_link",
                                         "base_link");
    this->declare_parameter<std::string>("odom",
                                         "odom");
    this->declare_parameter<std::float_t>("imu_linear_acceleration",
                                          0.0);
    this->declare_parameter<std::float_t>("imu_angular_velocity",
                                          0.0);
    // this->declare_parameter<std::true_type>("slam_path_enable",
    //                                     false);
}

void xvision_ros2_node::get_frameId_parameters(void)
{
    std::string frmaId;
    std::string paramName;
    rclcpp::Parameter frmaId_param;
    std::vector<std::string> paramNames{"map_optical_frame",
                                        "imu_optical_frame",
                                        "imu_optical_frame_unfiltered",
                                        "fisheye_left_optical_frame",
                                        "fisheye_right_optical_frame",
                                        "color_optical_frame",
                                        "sgbm_optical_frame",
                                        "tof_optical_frame",
                                        "imu_link",
                                        "base_link",
                                        "controller_port"};
    for (auto &param_name : paramNames)
    {
        bool ret = this->get_parameter_or(param_name, frmaId_param, rclcpp::Parameter(param_name, param_name));
        if (!ret)
        {
            printInfoMsg("get parameter is fail" + param_name);
            continue;
        }

        printInfoMsg(frmaId_param.value_to_string());
        m_frameID[param_name] = frmaId_param.value_to_string();
    }
}

void xvision_ros2_node::get_device_config_parameters(void)
{
    m_deviceConfig["slam_path_enable"] = false;
    m_deviceConfig["slam_pose_enable"] = true;
    m_deviceConfig["fisheye_enable"] = false;
    bool configState = false;
    for (auto &config_name : m_deviceConfig)
    {
        bool ret = this->get_parameter_or(config_name.first, configState, config_name.second);
        if (!ret)
        {
            printErrorMsg("Launch file has no " + config_name.first + " parameter");
            continue;
        }
        config_name.second = configState;
    }
    for (auto &config : m_deviceConfig)
    {
        std::cout << config.first << ":" << config.second << std::endl;
    }
}

void xvision_ros2_node::printInfoMsg(const std::string msgString) const
{
    RCLCPP_INFO(this->get_logger(), "xv_sdk: '%s'", msgString.c_str());
}

void xvision_ros2_node::printErrorMsg(const std::string msgString) const
{
    RCLCPP_ERROR(this->get_logger(), "xv_sdk: '%s'", msgString.c_str());
}

void xvision_ros2_node::publishImu(std::string sn, const rosImu &imuMsg)
{
    if (m_imuPublisher[sn])
    {
        m_imuPublisher[sn]->publish(imuMsg);
    }
}

void xvision_ros2_node::publisheOrientation(std::string sn, const rosOrientationStamped &orientationMsg)
{
    if (m_orientationPublisher[sn])
    {
        m_orientationPublisher[sn]->publish(orientationMsg);
    }
}

void xvision_ros2_node::publishFEImage(std::string sn,
                                       const rosImage &image,
                                       const rosCamInfo &cameraInfo,
                                       xv_dev_wrapper::FE_IMAGE_TYPE imageType)
{
    if (imageType == xv_dev_wrapper::FE_IMAGE_TYPE::LEFT_IMAGE)
    {
        if (m_fisheyeImageLeftPublisher[sn] && m_fisheyeImageLeftInfoPublisher[sn])
        {
            m_fisheyeImageLeftInfoPublisher[sn]->publish(cameraInfo);
            m_fisheyeImageLeftPublisher[sn].publish(image);
        }
    }
    else if (imageType == xv_dev_wrapper::FE_IMAGE_TYPE::RIGHT_IMAGE)
    {
        if (m_fisheyeImageRightPublisher[sn] && m_fisheyeImageRightInfoPublisher[sn])
        {
            m_fisheyeImageRightInfoPublisher[sn]->publish(cameraInfo);
            m_fisheyeImageRightPublisher[sn].publish(image);
        }
    }
    else if (imageType == xv_dev_wrapper::FE_IMAGE_TYPE::LEFT2_IMAGE)
    {
        if (m_fisheyeImageLeft2Publisher[sn] && m_fisheyeImageLeft2InfoPublisher[sn])
        {
            m_fisheyeImageLeft2InfoPublisher[sn]->publish(cameraInfo);
            m_fisheyeImageLeft2Publisher[sn].publish(image);
        }
    }
    else if (imageType == xv_dev_wrapper::FE_IMAGE_TYPE::RIGHT2_IMAGE)
    {
        if (m_fisheyeImageRight2Publisher[sn] && m_fisheyeImageRight2InfoPublisher[sn])
        {
            m_fisheyeImageRight2InfoPublisher[sn]->publish(cameraInfo);
            m_fisheyeImageRight2Publisher[sn].publish(image);
        }
    }
}

void xvision_ros2_node::publishFEAntiDistortionImage(std::string sn,
                                                     const rosImage &image,
                                                     const rosCamInfo &cameraInfo,
                                                     xv_dev_wrapper::FE_IMAGE_TYPE imageType)
{
    if (imageType == xv_dev_wrapper::FE_IMAGE_TYPE::LEFT_IMAGE)
    {
        if (m_fisheyeAntiDistortionLeftImagePublisher[sn] && m_fisheyeAntiDistortionCamLeftInfoPublisher[sn])
        {
            m_fisheyeAntiDistortionCamLeftInfoPublisher[sn]->publish(cameraInfo);
            m_fisheyeAntiDistortionLeftImagePublisher[sn].publish(image);
        }
    }
    else if (imageType == xv_dev_wrapper::FE_IMAGE_TYPE::RIGHT_IMAGE)
    {
        if (m_fisheyeAntiDistortionRightImagePublisher[sn] && m_fisheyeAntiDistortionCamRightInfoPublisher[sn])
        {
            m_fisheyeAntiDistortionCamRightInfoPublisher[sn]->publish(cameraInfo);
            m_fisheyeAntiDistortionRightImagePublisher[sn].publish(image);
        }
    }
}

void xvision_ros2_node::publishSlamPose(std::string sn, const geometry_msgs::msg::PoseStamped &pose)
{
    if (m_slam_pose_publisher[sn])
    {
        m_slam_pose_publisher[sn]->publish(pose);
    }
}

void xvision_ros2_node::publishSlamTrajectory(std::string sn, const nav_msgs::msg::Path &path)
{
    if (m_slam_path_publisher[sn])
    {
        m_slam_path_publisher[sn]->publish(path);
    }
}

void xvision_ros2_node::publishTofCameraImage(std::string sn, const rosImage &image, const rosCamInfo &cameraInfo)
{
    m_tof_camera_publisher[sn].publish(image); //, cameraInfo);
    m_tof_cameraInfo_pub[sn]->publish(cameraInfo);
}

void xvision_ros2_node::publishRGBCameraImage(std::string sn, const rosImage &image, const rosCamInfo &cameraInfo)
{
    m_rgb_camera_publisher[sn].publish(image); //, cameraInfo);
    m_rgb_cameraInfo_pub[sn]->publish(cameraInfo);
}

void xvision_ros2_node::publishRGBRectCameraImage(std::string sn, const rosImage &image, const rosCamInfo &cameraInfo)
{
    m_rgb_rect_camera_publisher[sn].publish(image);
    m_rgb_rect_cameraInfo_pub[sn]->publish(cameraInfo);
}

void xvision_ros2_node::publishSGBMImage(std::string sn, const rosImage &image, const rosCamInfo &cameraInfo)
{
    m_sgbm_camera_publisher[sn].publish(image); //, cameraInfo);
    m_sgbm_cameraInfo_pub[sn]->publish(cameraInfo);
}

void xvision_ros2_node::publishSGBMRawImage(std::string sn, const rosImage &image, const rosCamInfo &cameraInfo)
{
    m_sgbm_raw_camera_publisher[sn].publish(image); //, cameraInfo);
    m_sgbm_raw_cameraInfo_pub[sn]->publish(cameraInfo);
}

void xvision_ros2_node::publishRGBDCameraImage(std::string sn, const rosImage &image, const rosCamInfo &cameraInfo)
{
    m_rgbd_camera_publisher[sn].publish(image); //, cameraInfo);
    m_rgbd_cameraInfo_pub[sn]->publish(cameraInfo);
}

void xvision_ros2_node::publishRGBDRawCameraImage(std::string sn, const rosImage &image, const rosCamInfo &cameraInfo)
{
    m_rgbd_raw_camera_publisher[sn].publish(image); //, cameraInfo);
    m_rgbd_raw_cameraInfo_pub[sn]->publish(cameraInfo);
}

void xvision_ros2_node::publishRGBDRawCameraData(std::string sn, const rosColorDepth &colorDephData)
{
    if (m_rgbd_raw_data_publisher[sn])
    {
        m_rgbd_raw_data_publisher[sn]->publish(colorDephData);
    }
}

void xvision_ros2_node::publisheEvent(std::string sn, const rosEventData &eventMsg)
{
    if (m_eventPublisher[sn])
    {
        m_eventPublisher[sn]->publish(eventMsg);
    }
}

std::string xvision_ros2_node::getFrameID(const std::string &defaultId)
{
    std::string framId;
    this->get_parameter(defaultId, framId);
    return framId;
}

bool xvision_ros2_node::getConfig(std::string configName)
{
    return m_deviceConfig[configName];
}

void xvision_ros2_node::broadcasterTfTransform(const geometry_msgs::msg::TransformStamped &transform)
{
    if (m_static_tf_broadcaster)
    {
        m_static_tf_broadcaster->sendTransform(transform);
    }
}

void xvision_ros2_node::watchDevices(void)
{
    while (!m_stopWatchDevices)
    {
        xv::setLogLevel(xv::LogLevel::info);
        std::map<std::string, std::shared_ptr<Device>> device_map;
        std::string json = "";
        std::string jsonPath = "/etc/xvisio/config.json";
        std::ifstream ifs(jsonPath);
        if (ifs.is_open())
        {
            std::stringstream fbuf;
            fbuf << ifs.rdbuf();
            json = fbuf.str();
            ifs.close();
            std::this_thread::sleep_for(std::chrono::milliseconds(5000));
            device_map = getDevices(.0, json);
        }
        else
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(5000));
            device_map = getDevices(.0);
        }

        for (auto &pair : device_map)
        {
            m_devSerialNumber = pair.first;
            if (m_serialNumbers.empty())
            {
                std::cout << "find new device " << m_devSerialNumber << std::endl;
                m_serialNumbers.push_back(m_devSerialNumber);
                m_deviceMap.emplace(m_devSerialNumber, std::make_shared<xv_dev_wrapper>(this, device_map[m_devSerialNumber], m_devSerialNumber, 1));
                std::cout << "init device topic" << std::endl;
                initTopicAndServer(m_devSerialNumber);
            }
            else
            {
                auto it = find(m_serialNumbers.begin(), m_serialNumbers.end(), m_devSerialNumber);
                if (it == m_serialNumbers.end())
                {
                    std::cout << "find new device " << m_devSerialNumber << std::endl;
                    m_serialNumbers.push_back(m_devSerialNumber);
                    m_deviceMap.emplace(m_devSerialNumber, std::make_shared<xv_dev_wrapper>(this, device_map[m_devSerialNumber], m_devSerialNumber, 1));
                    std::cout << "init device topic" << std::endl;
                    initTopicAndServer(m_devSerialNumber);
                }
            }
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    }
}

void xvision_ros2_node::watchControllers(void)
{
    // while (!m_stopWatchDevices)
    // {
    //     xv::setLogLevel(xv::LogLevel::info);
    //     std::map<std::string, std::shared_ptr<Device>> controller_map;
    //     std::string json = "";
    //     std::string jsonPath = "/etc/xvisio/config.json";
    //     std::ifstream ifs(jsonPath);
    //     if (ifs.is_open())
    //     {
    //         std::stringstream fbuf;
    //         fbuf << ifs.rdbuf();
    //         json = fbuf.str();
    //         ifs.close();
    //         controller_map = getDevices(.0, json, nullptr, xv::SlamStartMode::Normal, xv::DeviceSupport::ONLY_WIRELESS_CONTROLLER);
    //     }
    //     else
    //     {
    //         controller_map = getDevices(.0, "", nullptr, xv::SlamStartMode::Normal, xv::DeviceSupport::ONLY_WIRELESS_CONTROLLER);
    //     }

    //     for(auto &pair : controller_map)
    //     {
    //         // m_controllerSerialNumber = pair.first;
    //         if(m_controllerSerials.empty())
    //         {
    //             std::cout << "new controller device" << std::endl;
    //             m_controllerSerials.push_back(m_controllerSerialNumber);
    //             m_controllerMap.emplace(m_controllerSerialNumber, std::make_shared<xv_dev_wrapper>(this, controller_map[pair.first], m_controllerSerialNumber, 2));
    //             initControllerTopicAndServer(m_controllerSerialNumber);
    //         }
    //         else
    //         {
    //             auto it = find(m_controllerSerials.begin(), m_controllerSerials.end(), m_controllerSerialNumber);
    //             if(it == m_controllerSerials.end())
    //             {
    //                 std::cout << "new controller device" << std::endl;
    //                 m_controllerSerials.push_back(m_controllerSerialNumber);
    //                 m_controllerMap.emplace(m_controllerSerialNumber, std::make_shared<xv_dev_wrapper>(this, controller_map[m_controllerSerialNumber], m_controllerSerialNumber, 2));
    //                 initControllerTopicAndServer("Controller");
    //             }
    //         }
    //     }
    //     std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    // }
}

void xvision_ros2_node::publishLeftControllerPose(std::string sn, const geometry_msgs::msg::PoseStamped &pose)
{
    if (m_controller_left_pose_publisher[sn])
    {
        m_controller_left_pose_publisher[sn]->publish(pose);
    }
}

void xvision_ros2_node::publishRightControllerPose(std::string sn, const geometry_msgs::msg::PoseStamped &pose)
{
    if (m_controller_right_pose_publisher[sn])
    {
        m_controller_right_pose_publisher[sn]->publish(pose);
    }
}

void xvision_ros2_node::publishLeftControllerData(std::string sn, const rosController &controllerMsg)
{
    if (m_controller_left_data_publisher[sn])
    {
        m_controller_left_data_publisher[sn]->publish(controllerMsg);
    }
}

void xvision_ros2_node::publishRightControllerData(std::string sn, const rosController &controllerMsg)
{
    if (m_controller_right_data_publisher[sn])
    {
        m_controller_right_data_publisher[sn]->publish(controllerMsg);
    }
}

void xvision_ros2_node::publisheButton(std::string sn, int buttonType, const rosButtonMsg &buttonMsg)
{
    switch (buttonType)
    {
    case 1:
        if (m_buttonPublisher1[sn])
        {
            m_buttonPublisher1[sn]->publish(buttonMsg);
        }
        break;
    case 2:
        if (m_buttonPublisher2[sn])
        {
            m_buttonPublisher2[sn]->publish(buttonMsg);
        }
        break;
    case 3:
        if (m_buttonPublisher3[sn])
        {
            m_buttonPublisher3[sn]->publish(buttonMsg);
        }
        break;
    case 4:
        if (m_buttonPublisher4[sn])
        {
            m_buttonPublisher4[sn]->publish(buttonMsg);
        }
        break;
    }
}

void xvision_ros2_node::publishRGBPointCloud(std::string sn, rosPointCloud2 pointclouds, const rosCamInfo &cameraInfo)
{
    if (m_rgbPointCloudPublisher[sn])
    {
        m_rgbPointCloudPublisher[sn]->publish(pointclouds);
    }
    
    if (m_rgbPointCloud_cameraInfo_pub[sn])
    {
        m_rgbPointCloud_cameraInfo_pub[sn]->publish(cameraInfo);
    }
}

void xvision_ros2_node::publishClamp(std::string sn, rosClamp clamp)
{
    if (m_clampPublisher[sn])
    {
        m_clampPublisher[sn]->publish(clamp);
    }
}

void xvision_ros2_node::publishLeftSpherePose(std::string sn, const geometry_msgs::msg::PoseStamped &pose)
{
    if (m_leftSpherePublisher[sn])
    {
        m_leftSpherePublisher[sn]->publish(pose);
    }
}

void xvision_ros2_node::publishRightSpherePose(std::string sn, const geometry_msgs::msg::PoseStamped &pose)
{
    if (m_rightSpherePublisher[sn])
    {
        m_rightSpherePublisher[sn]->publish(pose);
    }
}
