var searchData=
[
  ['details_516',['details',['../namespacexv_1_1details.html',1,'xv']]]
];
