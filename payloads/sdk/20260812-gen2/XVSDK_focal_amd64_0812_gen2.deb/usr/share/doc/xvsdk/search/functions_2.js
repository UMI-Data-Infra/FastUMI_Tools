var searchData=
[
  ['depthimagetopointcloud_525',['depthImageToPointCloud',['../classxv_1_1TofCamera.html#a437c5475eed22400f867802b526ac825',1,'xv::TofCamera::depthImageToPointCloud()'],['../classxv_1_1SgbmCamera.html#a21d14272523d55124f867ebf73dd8e67',1,'xv::SgbmCamera::depthImageToPointCloud()']]],
  ['detachdevice_526',['detachDevice',['../group__xv__android__functions.html#ga584b3ceae982b9d582f3ce4fcbd26f8d',1,'xv']]],
  ['devicestatus_527',['deviceStatus',['../classxv_1_1Device.html#a712f2709e1e48f480cfa343efaa15133',1,'xv::Device']]],
  ['display_528',['display',['../classxv_1_1Device.html#a088d0774607e803076cb889e70af2036',1,'xv::Device']]]
];
