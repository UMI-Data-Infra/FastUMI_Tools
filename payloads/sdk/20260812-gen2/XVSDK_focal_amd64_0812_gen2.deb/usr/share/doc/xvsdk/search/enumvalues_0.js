var searchData=
[
  ['rgb_5f1280x720_757',['RGB_1280x720',['../classxv_1_1ColorCamera.html#acb488c507a1956ac0016953a60740cd4a0204b6588463932d4cffb3d491f995cf',1,'xv::ColorCamera']]],
  ['rgb_5f1296x1416_5f4k_758',['RGB_1296x1416_4K',['../classxv_1_1ColorCamera.html#acb488c507a1956ac0016953a60740cd4aa17d0718047fe0d163a0d73180965648',1,'xv::ColorCamera']]],
  ['rgb_5f1296x1416_5fdown_5fsample_5f4k_759',['RGB_1296x1416_down_sample_4K',['../classxv_1_1ColorCamera.html#acb488c507a1956ac0016953a60740cd4a3a62d5948466d7356ddf1f2c47a4faba',1,'xv::ColorCamera']]],
  ['rgb_5f1920x1080_760',['RGB_1920x1080',['../classxv_1_1ColorCamera.html#acb488c507a1956ac0016953a60740cd4ad443f2678079887c727958de510a1bf3',1,'xv::ColorCamera']]],
  ['rgb_5f2312x1736_761',['RGB_2312x1736',['../classxv_1_1ColorCamera.html#acb488c507a1956ac0016953a60740cd4a1d0eee55c388237f497f865194e4afcb',1,'xv::ColorCamera']]],
  ['rgb_5f2560x1920_762',['RGB_2560x1920',['../classxv_1_1ColorCamera.html#acb488c507a1956ac0016953a60740cd4af3c688ba31f9bc87d6aeb7de15aa7d5c',1,'xv::ColorCamera']]],
  ['rgb_5f2880x3072_763',['RGB_2880x3072',['../classxv_1_1ColorCamera.html#acb488c507a1956ac0016953a60740cd4a53873e9c1a440895aad25f8fcdd43ca2',1,'xv::ColorCamera']]],
  ['rgb_5f320x240_764',['RGB_320x240',['../classxv_1_1ColorCamera.html#acb488c507a1956ac0016953a60740cd4ab2033a0bd383b22f20c9341003743f75',1,'xv::ColorCamera']]],
  ['rgb_5f640x480_765',['RGB_640x480',['../classxv_1_1ColorCamera.html#acb488c507a1956ac0016953a60740cd4a8d7edbd65d6c73ca311635fe0bf6a3f0',1,'xv::ColorCamera']]]
];
