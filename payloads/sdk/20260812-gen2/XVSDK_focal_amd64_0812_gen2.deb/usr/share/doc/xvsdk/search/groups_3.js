var searchData=
[
  ['version_20helper_2e_772',['Version helper.',['../group__Version.html',1,'']]]
];
