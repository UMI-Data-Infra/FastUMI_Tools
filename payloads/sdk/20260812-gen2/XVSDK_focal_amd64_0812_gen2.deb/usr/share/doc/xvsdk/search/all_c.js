var searchData=
[
  ['normal_145',['normal',['../structxv_1_1Plane.html#a47ab7c83175d6b47fd2f6883081a10d8',1,'xv::Plane']]]
];
