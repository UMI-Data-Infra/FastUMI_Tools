var searchData=
[
  ['version_662',['version',['../group__xv__functions.html#gabd454b2c2709816673098d35a9daad87',1,'xv']]],
  ['vscwriteandread_663',['vscWriteAndRead',['../classxv_1_1Device.html#a3b2664e9c205127107f0ff7011fd0cb1',1,'xv::Device']]],
  ['vstcamera_664',['vstCamera',['../classxv_1_1Device.html#a41e320545cb4b2e1f0c462516ee39d73',1,'xv::Device']]]
];
