var searchData=
[
  ['object_421',['Object',['../structxv_1_1Object.html',1,'xv']]],
  ['objectdescriptor_422',['ObjectDescriptor',['../structxv_1_1ObjectDescriptor.html',1,'xv']]],
  ['objectdetector_423',['ObjectDetector',['../classxv_1_1ObjectDetector.html',1,'xv']]],
  ['objectdetectorrknn3588_424',['ObjectDetectorRKNN3588',['../classxv_1_1ObjectDetectorRKNN3588.html',1,'xv']]],
  ['orientation_425',['Orientation',['../classxv_1_1Orientation.html',1,'xv']]],
  ['orientationstream_426',['OrientationStream',['../classxv_1_1OrientationStream.html',1,'xv']]]
];
