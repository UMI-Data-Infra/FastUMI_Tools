var searchData=
[
  ['gazecalibrationdata_403',['GazeCalibrationData',['../structxv_1_1GazeCalibrationData.html',1,'xv']]],
  ['gazeconfigs_404',['GazeConfigs',['../structxv_1_1GazeConfigs.html',1,'xv']]],
  ['gazestream_405',['GazeStream',['../classxv_1_1GazeStream.html',1,'xv']]],
  ['gesturedata_406',['GestureData',['../structxv_1_1GestureData.html',1,'xv']]],
  ['gesturestream_407',['GestureStream',['../classxv_1_1GestureStream.html',1,'xv']]],
  ['gpsdistancedata_408',['GPSDistanceData',['../structxv_1_1GPSDistanceData.html',1,'xv']]],
  ['gpsdistancestream_409',['GPSDistanceStream',['../classxv_1_1GPSDistanceStream.html',1,'xv']]],
  ['gpsstream_410',['GPSStream',['../classxv_1_1GPSStream.html',1,'xv']]],
  ['grayscaleimage_411',['GrayScaleImage',['../structxv_1_1GrayScaleImage.html',1,'xv']]]
];
