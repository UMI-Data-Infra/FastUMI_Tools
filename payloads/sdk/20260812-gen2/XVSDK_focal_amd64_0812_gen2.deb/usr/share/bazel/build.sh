#!/bin/bash

# bazel build //main:pipe_srv

# bazel build //main:demo-api

# bazel build //main:all_stream

bazel build //main:multi-devices
