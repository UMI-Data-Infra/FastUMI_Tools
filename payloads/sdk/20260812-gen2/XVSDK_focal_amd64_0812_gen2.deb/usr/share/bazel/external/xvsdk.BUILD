load("@rules_cc//cc:defs.bzl", "cc_library","cc_import")
cc_library(
    name = "xvsdk",
    srcs = glob(["include/xvsdk/*.h","include2/*.h","lib/*.a*","lib/*.so*"]),
    includes = ["include/xvsdk","include2"],
    linkopts = ["-Llib","-L/usr/lib","-ljpeg","-L/usr/lib/x86_64-linux-gnu"],
    visibility = ["//visibility:public"],
)