#define _USE_MATH_DEFINES
#include "CInterfaceGeneral.h"
#include "CInterfaceTypes.h"
#include <iostream>
#include <thread>
#include <mutex>
#include <cmath>
#include <iostream>
#include "fps_count.hpp"
#include <cstring>

Fisheye_images fisheye_image;

Color_Image color_image;
struct FpsCount fe_fps;
struct FpsCount rgb_fps;
struct FpsCount slam_fps;

void fisheye_register_callback(Fisheye_images* images, const char* device_name)
{
    fisheye_image.host_timestamp = images->host_timestamp;
    fisheye_image.edge_timestamp_us = images->edge_timestamp_us;
    fisheye_image.image_number = images->image_number;
    fisheye_image.id = images->id;
    for(int i = 0; i < fisheye_image.image_number; i++)
    {
        fisheye_image.images[i].width = images->images[i].width;
        fisheye_image.images[i].height = images->images[i].height;
        if(fisheye_image.images[i].data == nullptr)
        {
            fisheye_image.images[i].data = (int8_t*)malloc(images->images[i].width * images->images[i].height);
        }
        if(fisheye_image.images[i].data != nullptr)
        {
            memcpy(fisheye_image.images[i].data, images->images[i].data, images->images[i].width * images->images[i].height);
        }
    }

    fe_fps.tic();
    static int k = 0;
    if(k++%50==0){
        std::cout<<std::string(device_name)<<"  fisheye callback:"<<images->image_number<<" width:"<<images->images[0].width
        <<" height:"<<images->images[0].height<<"@"<<std::round(fe_fps.fps())<<" fps" <<std::endl;
    }
}

void rgb_register_callback(Color_Image* image, const char* device_name)
{   
    color_image.height = image->height;
    color_image.width = image->width;
    color_image.codec = image->codec;
    color_image.data_size = image->data_size;
    color_image.host_timestamp = image->host_timestamp;
    color_image.edge_timestamp_us = image->edge_timestamp_us;

    if(color_image.data == nullptr)
    {
        color_image.data = (uint8_t*)malloc(color_image.data_size);
    }
    if(color_image.data != nullptr)
    {
        memcpy(color_image.data, image->data, color_image.data_size);
    }

    slam_fps.tic();
    static int k = 0;
    if(k++%50==0){
        std::cout<<std::string(device_name)<<"  rgb callback  width:"<<image->width
        <<" height:"<<image->height<<"@"<<std::round(slam_fps.fps())<<" fps" <<std::endl;
    }
}

void slam_register_callback(Slam_Pose pose, const char* device_name)
{
    rgb_fps.tic();
    static int k = 0;
    if(k++%500==0){
        std::cout<<std::string(device_name)<<"  slam callbcak x:"<<pose.position.x
        <<" y:"<<pose.position.y<<" z:"<<pose.position.z<<"@"<<std::round(rgb_fps.fps())<<" fps" <<std::endl;
    }
}

void gesture_register_callback(Gesture_Data data, const char* device_name)
{
    // std::cout<<"------------------------------"<<std::string(device_name)<<std::endl;
    // for(int i = 0; i < GESTURE_DATA_SIZE; i++)
    // {
    //     std::cout<<"i:"<<i<<" x:"<<data.pose[i].position.x<<
    //     " y:"<<data.pose[i].position.y<<
    //     " z:"<<data.pose[i].position.z<<std::endl;
    // }
}

void save_cslam_done_callback(int status,  int quality, const char* device_name)
{
    std::cout<<"status:"<<status<<" quality:"<<quality<<" device name:"<<std::string(device_name)<<std::endl;
}

void cslam_localized_callback(float percent, const char* device_name)
{
    std::cout<<"percent:"<<percent<<" device name:"<<std::string(device_name)<<std::endl;
}

void cslam_done_callback(int status,const char* device_name)
{
    std::cout<<"status:"<<status<<" device name:"<<std::string(device_name)<<std::endl;
}

int main()
{
    Version_Struct version;
    bool ret = get_sdk_version(&version);
    if(ret)
    {
        std::cout<<"SDK version:"<<std::string(version.buffer)<<std::endl;
    }

    Devices* devices = get_devices_until_timeout(10, nullptr, NORMAL, ONLY_USB);
    for(int i = 0;i < devices->size; i++)
    {
        bool ret = start_fisheye(devices->item[i].handle);
        if(ret)
        {
            register_fisheye_callback(devices->item[i].handle, fisheye_register_callback);
        }

        ret = start_slam(devices->item[i].handle);
        if(ret)
        {
            register_slam_callback(devices->item[i].handle, slam_register_callback);
        }

        ret = start_rgb(devices->item[i].handle);
        if(ret)
        {
            register_rgb_callback(devices->item[i].handle, rgb_register_callback);
        }

        set_gesture_platform(devices->item[i].handle, 0, true);
        ret = start_gesture(devices->item[i].handle);
        if(ret)
        {
            register_gesture_slam_keypoints_callback(devices->item[i].handle, gesture_register_callback);
        }
    }
    while(1)
    {
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
        char temp = std::cin.get();
        if(temp == 's')
        {
            save_map_and_switch_to_Cslam(devices->item[0].handle, "map.bin", save_cslam_done_callback, cslam_localized_callback);
        }
        else if(temp == 'l')
        {
            load_map_and_switch_to_Cslam(devices->item[0].handle, "map.bin", cslam_done_callback, cslam_localized_callback);
        }
    }
}
